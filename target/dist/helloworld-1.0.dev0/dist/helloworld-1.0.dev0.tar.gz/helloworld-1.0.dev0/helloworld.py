import sys

def helloworld(out):
    out.write("Hello World of Python\n")